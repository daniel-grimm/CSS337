<?php 
 
  //system("cat setgetcookie.htm");
   $uname = $_GET['username'];
   $greeting = "Hello ".$uname;
   system("echo $greeting");

?>
